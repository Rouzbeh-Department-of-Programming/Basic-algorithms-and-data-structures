n = int(input())
i = 1
while i < n:
    i *= 2

print(i)